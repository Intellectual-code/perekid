function createSnowflakes() {
    const body = document.querySelector('body');
    const snowflakeCount = 150; // Количество снежинок (можно увеличить или уменьшить)

    for (let i = 0; i < snowflakeCount; i++) {
      const snowflake = document.createElement('div');
      snowflake.classList.add('snowflake');
      
      // Случайный размер снежинки (от 2px до 7px)
      const size = Math.random() * 5 + 2 + 'px';
      snowflake.style.width = size;
      snowflake.style.height = size;
      
      // Случайная позиция по горизонтали (от 0 до 100% ширины экрана)
      snowflake.style.left = Math.random() * 100 + 'vw';
      
      // Случайная длительность падения (от 3 до 8 секунд)
      snowflake.style.animationDuration = Math.random() * 5 + 3 + 's';
      
      // Случайная задержка перед началом анимации (чтобы они не падали все одновременно)
      snowflake.style.animationDelay = Math.random() * 5 + 's';
      
      // Случайная прозрачность для эффекта глубины резкости
      snowflake.style.opacity = Math.random() * 0.7 + 0.3;
      
      body.appendChild(snowflake);
    }
  }

  // Запускаем создание снежинок после загрузки страницы
  document.addEventListener('DOMContentLoaded', createSnowflakes);

  function open() {
   
    const card = document.getElementById("card");
    console.log(card);

}