

function Products(){
    return (
        <div className="products">
            <div className="product-card">
                <div className="top-card">
                    <div className="image-card">
                        <img src="./iph.png" alt="img"/>
                    </div>
                    <div className="btn-card">
                        <div className="title">Iphone 17 pro max 256gb</div>
                        <div className="describe">Новый Iphone 17 pro max 2026</div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Products;