import log from "./1.png"
import log1 from "./prof.png"
import "./App.css"
import "./Products"
import "./Products.css"
import Products from "./Products";
function App() {
  return (
    <div className="App">
      <header>
        <div className="logo">
            <img src={log}></img>
        </div>
        <div className="navi">
        <p>Home</p>
        <p>About us</p>
        <p>Product</p>
        </div>
        <div className="auth">
        <img src={log1}></img>
        </div>
      </header>
      <Products></Products>

    </div>
  );
}

export default App;
